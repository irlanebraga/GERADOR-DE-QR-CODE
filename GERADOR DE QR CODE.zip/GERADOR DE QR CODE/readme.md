
# Bem-vindo ao Gerador de QR Codes

Neste projeto, você poderá gerar e baixar QR Codes automaticamente a partir de uma simples página da *web*. Tudo o que você precisa fazer é inserir o texto ou link desejado e o QR Code será gerado instantaneamente.

Utilizamos a biblioteca React juntamente com o build tool Vite para o desenvolvimento desta página, garantindo uma experiência de usuário rápida e eficiente. Além disso, estamos sempre atualizando nosso código para oferecer a você a melhor experiência possível.

###### Se você deseja clonar este projeto, lembre-se:

Para instalar as dependências: `npm install`.

Para rodar o projeto localmente: `npm run dev`.

![Projeto Prático I](https://uploaddeimagens.com.br/images/004/330/210/original/page.png?1675570994)
